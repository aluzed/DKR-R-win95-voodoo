# Build validation record

Validation date: **29 July 2026**

## Milestone

This package is **0.4.4-dev — N64Recomp diagnostic capture and runtime preparation**.

It builds on the user-confirmed Windows 0.3 launcher/input baseline and adds:

- larger launcher typography and deliberate vertical spacing;
- a full-width controls table;
- matching DKR ELF build automation;
- N64Recomp/N64ModernRuntime/RT64 preparation;
- generated-code/runtime compilation probe;
- clean-package exclusions for every generated/runtime artefact.

It does not claim that the DKR title screen, graphics or audio are already running.

## Windows evidence inherited from earlier milestones

A real Windows/Visual Studio 2022 Release build has confirmed:

- native CMake and MSVC selection;
- pinned vcpkg setup;
- SDL3 3.4.10 and RmlUi 6.2 compilation;
- the final native launcher executable;
- successful validation of a real DKR US 1.0 ROM;
- functional keyboard/controller remapping and live input packets;
- matching DKR ELF and ROM output under WSL, including verified CIC-6103 CRCs;
- successful Windows builds of the runtime-pinned N64Recomp and RSPRecomp tools;
- successful pinned RT64 checkout.

## Validation performed for 0.4

- GCC release core build with warnings treated as errors.
- Clang debug core build with AddressSanitizer and UndefinedBehaviourSanitizer.
- Complete unit test executable.
- Headless application self-test.
- Native UI strict C++20 syntax compilation against the exact SDL3/RmlUi headers from the working
  Windows vcpkg installation.
- RML XML parsing, unique element IDs and C++ binding-ID checks.
- RCSS brace/structure checks.
- PowerShell/runtime CMake static review, including the official N64Recomp `[input]` TOML layout and BOM-free UTF-8 output.
- Explicit asynchronous capture of N64Recomp stdout and stderr into separate diagnostic files.
- A dedicated `Diagnose-DKR-Recompile.cmd` command that reruns only the prepared N64Recomp boundary.
- WSL path conversion updated to use `wsl.exe --exec wslpath`, preserving Windows backslashes without an intermediate shell parse.
- WSL build commands now pass the source path and job count as positional Bash arguments rather than interpolating them into shell text.
- Repository game-asset scan.
- Clean full-ZIP extraction and dependency-free core rebuild.
- Clean overwrite-upgrade extraction over the user-provided 0.3 repository, followed by file-for-file comparison and rebuild.

## Runtime-preparation validation limit

The complete `Build-DKR-Runtime.cmd` flow cannot be executed in the packaging environment because it
requires the user's legally obtained ROM, their Windows/WSL installation and a large local dependency
build. The script is therefore designed to retain full transcripts and MSBuild logs and to stop at the
first concrete DKR-specific recompiler/compiler blocker rather than report a false success.

## Package safety

The release ZIP contains no ROM, source-ROM path, generated O2R, matching ROM output, extracted asset,
recompiled CPU output, dependency checkout, save, runtime config, log or build directory.
