#pragma once

#define DKRPORT_VERSION_MAJOR 0
#define DKRPORT_VERSION_MINOR 4
#define DKRPORT_VERSION_PATCH 4
#define DKRPORT_VERSION_STRING "0.4.4-dev"
#define DKRPORT_BUILD_MILESTONE "Milestone 0.4 — N64Recomp diagnostics and runtime preparation"
