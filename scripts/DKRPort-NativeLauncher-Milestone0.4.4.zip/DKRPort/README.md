# DKR Port

**Milestone 0.4.4 — N64Recomp diagnostics and runtime preparation**

DKR Port is an early cross-platform native port project for _Diddy Kong Racing_. The repository and
its release ZIP contain no ROM, extracted texture, model, audio, font or other original game asset.

> **Current status:** the Windows launcher validates a user-owned US 1.0 ROM, stores only its local
> path and hash, provides persistent remappable controls, and produces N64-format input packets. This
> milestone also adds the first reproducible DKR ELF → N64Recomp → N64ModernRuntime compilation
> pipeline. It does **not** yet render the DKR title screen or play original game audio.

## Milestone 0.4 changes

### Launcher and controls

- Main wording aligned with the supplied **Diddy Kong Racing on PC!?** launcher revision.
- Default window increased to 1600×900, with a 1280×720 minimum.
- Larger headings, body text, labels, buttons, status cards and modal copy.
- Deliberate spacing between headings, descriptions, cards and actions instead of blank `<br/>` lines.
- Controls rebuilt as a full-width three-column table: Action, Keyboard and Controller.
- Analogue source, deadzone, inversion and reset options moved into a horizontal panel.
- Existing keyboard/controller remapping and hot-plug support retained.

### Native game-code preparation

Run **`Build-DKR-Runtime.cmd`** to prepare the first real game-code boundary. It will:

1. Find the ROM already connected by the launcher, or ask for it.
2. Normalise `.z64`, `.v64` or `.n64` and verify the US 1.0 SHA-1.
3. Clone the exact pinned DKR decomp revision.
4. Build the matching DKR ROM and ELF under WSL.
5. Clone N64ModernRuntime recursively and build the exact N64Recomp revision pinned by its submodule.
6. Generate native C functions from the matching DKR ELF/ROM.
7. Compile those generated functions against N64ModernRuntime.
8. Optionally configure RT64 with `Build-DKR-Runtime.cmd -BuildRenderer`.
9. Save exact resolved dependency commits and diagnostic logs locally.

This command is expected to expose DKR-specific recompilation/runtime blockers as normal engineering
work. It does not claim that a playable game exists merely because generated CPU code compiles.

If the full preparation has already reached N64Recomp, run **`Diagnose-DKR-Recompile.cmd`** to rerun
only the prepared recompilation step. It captures stdout and stderr into separate `build-logs`
files without rebuilding the decomp ELF, WSL environment, N64Recomp or RT64.

## Windows launcher build

1. Extract the repository to a short writable path such as `C:\DKRPort`.
2. Double-click **`Build-Windows.cmd`**.
3. Allow requested administrator or package-manager prompts.
4. Double-click **`Run-Windows.cmd`** after a successful build.

The builder checks for or installs:

- Git for Windows.
- Native Kitware or Visual Studio CMake 3.24+.
- Visual Studio 2022 C++ tools and Windows SDK.
- A pinned vcpkg registry.
- SDL3 3.4.10 and RmlUi 6.2 with FreeType.

Detailed text and binary MSBuild logs are written under `build-logs`. The runnable launcher package is
created under `dist\DKRPort-Windows-x64`.

## Controls

Open **Controls** from the launcher or press `F1` in the ROM-backed host screen. Select a binding and
press the replacement keyboard key or controller input.

Default keyboard layout:

```text
Analogue: W A S D       A button: Space       B button: Left Ctrl
Z trigger: Left Shift   Start: Return         L/R: Q / E
C buttons: I J K L      D-pad: Arrow keys
```

Settings are stored in `runtime\config\controls.json` in portable mode. The runtime-facing packet uses
the original N64 button mask and signed analogue values in the `-80` to `+80` range.

## Supported ROM

```text
Diddy Kong Racing US 1.0 / v77
SHA-1: 0cb115d8716dbbc2922fda38e533b9fe63bb9670
```

The ROM itself is never included in a source/release archive and is not copied into the generated
manifest archive.

## What “Start Game” currently does

The launcher still enters the validated ROM-backed host telemetry screen. It reopens and verifies the
ROM, parses the N64 header, creates a cleared 4 MiB RDRAM compatibility arena, runs a fixed 60 Hz host
tick and emits live remapped N64 controller packets.

The actual native DKR executable is being prepared separately under `runtime-recomp`. The remaining
playable-boot work includes:

- DKR game registration and a verified generated entrypoint callback;
- DKR-specific instruction patches and hardware stubs;
- PI/save callbacks;
- Rare F3DDKR graphics microcode recompilation and RT64 binding;
- audio microcode recompilation and host audio callback;
- connecting the existing remappable input packets to the running game;
- boot, save and complete-game regression testing.

## Commands

```text
Build-Windows.cmd
Run-Windows.cmd
Prepare-Game-Source.cmd
Build-DKR-Runtime.cmd
Diagnose-DKR-Recompile.cmd

DKRPort [--portable]
DKRPort --validate-rom <path> [--portable]
DKRPort --self-test [--portable]
DKRPort --headless-self-test [--portable]
DKRPort --renderer-test [output.svg] [--portable]
DKRPort --version
```

## Documentation

- [Milestone 0.4 scope](docs/MILESTONE_0_4.md)
- [Building](docs/BUILDING.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Runtime work area](runtime-recomp/README.md)
- [Roadmap](docs/ROADMAP.md)
- [F3DDKR notes](docs/F3DDKR.md)
- [ROM setup and privacy](docs/ROM_SETUP.md)
- [Asset policy](docs/ASSET_POLICY.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Validation record](BUILD-VALIDATION.md)

## Legal position

This is an unofficial porting project. Users must supply their own legally obtained copy of the game.
The project is not affiliated with, authorised by or endorsed by Nintendo or Rare. Read
[ASSET_POLICY.md](docs/ASSET_POLICY.md) before contributing.

## Next milestone

The first native-game boot and one-click release workflow are specified in
[`docs/MILESTONE_0_5_PLAN.md`](docs/MILESTONE_0_5_PLAN.md).
