# DKR Native Runtime Work Area

This directory contains source-controlled preparation for the first executable that runs original DKR
CPU code natively.

Run from the repository root:

```text
Build-DKR-Runtime.cmd
```

The command:

1. Reuses the ROM path already validated by the launcher, or opens a selector.
2. Normalises the ROM and rechecks the US 1.0 SHA-1.
3. Builds the pinned DKR decomp under WSL and verifies the matching ELF/ROM output.
4. Builds the exact N64Recomp submodule revision pinned by N64ModernRuntime on Windows.
5. Generates a first-pass TOML from the matching ELF, ROM and N64 entrypoint.
6. Emits native C functions into `RecompiledFuncs/`.
7. Builds those functions together with N64ModernRuntime in `DKRRuntimeProbe`.
8. Optionally configures RT64 when `-BuildRenderer` is supplied.
9. Writes resolved dependency commits and the reached boundary to a local ignored JSON report.

## Generated/local-only files

These must never enter a source or release archive:

- `RecompiledFuncs/`
- `dkr.us.v77.generated.toml`
- `resolved-runtime-dependencies.json`
- all files under `extern/n64-modern-runtime` and `extern/rt64`
- DKR ROMs, built matching ROMs and extracted game assets
- runtime compiler logs and build directories

## What the probe proves

A successful `DKRRuntimeProbe` proves that:

- the matching DKR ELF can be produced;
- the N64Recomp revision paired with the runtime can emit DKR CPU translation files;
- those generated files can compile in the same build as `ultramodern` and `librecomp`;
- optional RT64 source can be cloned and admitted to the build only when requested.

It does **not** prove that DKR boots. A playable executable still requires DKR game registration,
project callbacks, patches, Rare F3DDKR/audio RSP recompilation and a renderer/audio host.

## Why the decomp remains central

Static recompilation translates the original DKR binary, but the completed decomp supplies the
matching ELF, symbols, structures and readable game logic needed to understand and patch the output.
This is not a generic emulator and accepts only the supported DKR revision.
