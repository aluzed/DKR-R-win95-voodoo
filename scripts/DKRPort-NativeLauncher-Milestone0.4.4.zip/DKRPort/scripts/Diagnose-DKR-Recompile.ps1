[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$LogDirectory = Join-Path $ProjectRoot 'build-logs'
$RuntimeRoot = Join-Path $ProjectRoot 'runtime-recomp'
$TomlPath = Join-Path $RuntimeRoot 'dkr.us.v77.generated.toml'
$Timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$StdoutLog = Join-Path $LogDirectory "n64recomp-$Timestamp.stdout.log"
$StderrLog = Join-Path $LogDirectory "n64recomp-$Timestamp.stderr.log"

New-Item -ItemType Directory -Force -Path $LogDirectory | Out-Null

function Fail([string]$Message) {
    throw $Message
}

try {
    Write-Host 'DKR Port - rerun the prepared N64Recomp boundary'
    Write-Host "Project: $ProjectRoot"
    Write-Host ''

    if (-not (Test-Path -LiteralPath $TomlPath -PathType Leaf)) {
        Fail "The generated N64Recomp configuration is missing: $TomlPath Run Build-DKR-Runtime.cmd first."
    }

    $Recompiler = Get-ChildItem `
        -LiteralPath (Join-Path $ProjectRoot 'build\runtime-tools\n64recomp') `
        -Filter 'N64Recomp.exe' `
        -File `
        -Recurse `
        -ErrorAction SilentlyContinue |
        Select-Object -First 1

    if (-not $Recompiler) {
        Fail 'N64Recomp.exe is missing. Run Build-DKR-Runtime.cmd first.'
    }

    Write-Host "[OK] N64Recomp: $($Recompiler.FullName)" -ForegroundColor Green
    Write-Host "[OK] Configuration: $TomlPath" -ForegroundColor Green
    Write-Host ''
    Write-Host 'Running N64Recomp. This command reuses the already-built DKR ELF and does not rerun WSL setup.' -ForegroundColor Cyan

    $Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $StartInfo = New-Object System.Diagnostics.ProcessStartInfo
    $StartInfo.FileName = $Recompiler.FullName
    $StartInfo.Arguments = '"' + $TomlPath + '"'
    $StartInfo.WorkingDirectory = $RuntimeRoot
    $StartInfo.UseShellExecute = $false
    $StartInfo.CreateNoWindow = $true
    $StartInfo.RedirectStandardOutput = $true
    $StartInfo.RedirectStandardError = $true

    $Process = New-Object System.Diagnostics.Process
    $Process.StartInfo = $StartInfo
    if (-not $Process.Start()) {
        Fail 'N64Recomp could not be started.'
    }

    $StdoutTask = $Process.StandardOutput.ReadToEndAsync()
    $StderrTask = $Process.StandardError.ReadToEndAsync()
    $Process.WaitForExit()
    $ExitCode = $Process.ExitCode
    $Stdout = $StdoutTask.Result
    $Stderr = $StderrTask.Result
    $Process.Dispose()

    [System.IO.File]::WriteAllText($StdoutLog, $Stdout, $Utf8NoBom)
    [System.IO.File]::WriteAllText($StderrLog, $Stderr, $Utf8NoBom)

    if (-not [string]::IsNullOrWhiteSpace($Stdout)) {
        Write-Host ''
        Write-Host '==> N64Recomp standard output'
        Write-Host $Stdout.TrimEnd()
    }
    if (-not [string]::IsNullOrWhiteSpace($Stderr)) {
        Write-Host ''
        Write-Host '==> N64Recomp diagnostic output' -ForegroundColor Yellow
        Write-Host $Stderr.TrimEnd() -ForegroundColor Yellow
    }

    Write-Host ''
    Write-Host "stdout log: $StdoutLog"
    Write-Host "stderr log: $StderrLog"

    if ($ExitCode -ne 0) {
        Write-Host ''
        Write-Host "[FAILED] N64Recomp returned exit code $ExitCode." -ForegroundColor Red
        exit $ExitCode
    }

    Write-Host ''
    Write-Host '[OK] N64Recomp completed successfully.' -ForegroundColor Green
    exit 0
} catch {
    Write-Host ''
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "stdout log: $StdoutLog"
    Write-Host "stderr log: $StderrLog"
    exit 1
}
